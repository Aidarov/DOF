--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.tablet_users DROP CONSTRAINT IF EXISTS tablet_users_pkey;
ALTER TABLE IF EXISTS ONLY public.tablet_user_session DROP CONSTRAINT IF EXISTS tablet_user_session_pkey;
ALTER TABLE IF EXISTS ONLY public.oil_wells DROP CONSTRAINT IF EXISTS oil_wells_pkey;
ALTER TABLE IF EXISTS ONLY public.oil_fields DROP CONSTRAINT IF EXISTS oil_fields_pkey;
ALTER TABLE IF EXISTS ONLY public.oil_well_equipments DROP CONSTRAINT IF EXISTS oil_equipment_types_pkey;
ALTER TABLE IF EXISTS ONLY public.measures DROP CONSTRAINT IF EXISTS measures_pkey;
ALTER TABLE IF EXISTS ONLY public.equipment_values DROP CONSTRAINT IF EXISTS equipment_values_pkey;
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS devices_pkey;
ALTER TABLE IF EXISTS ONLY public.device_paths DROP CONSTRAINT IF EXISTS device_paths_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tablet_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tablet_user_session ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oil_wells ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oil_well_equipments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oil_fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.measures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.equipment_values ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.devices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.device_paths ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_sessions_id_seq;
DROP TABLE IF EXISTS public.user_sessions;
DROP SEQUENCE IF EXISTS public.tablet_users_id_seq;
DROP TABLE IF EXISTS public.tablet_users;
DROP SEQUENCE IF EXISTS public.tablet_user_session_id_seq;
DROP TABLE IF EXISTS public.tablet_user_session;
DROP SEQUENCE IF EXISTS public.oil_wells_id_seq;
DROP TABLE IF EXISTS public.oil_wells;
DROP SEQUENCE IF EXISTS public.oil_fields_id_seq;
DROP TABLE IF EXISTS public.oil_fields;
DROP SEQUENCE IF EXISTS public.oil_equipment_types_id_seq;
DROP TABLE IF EXISTS public.oil_well_equipments;
DROP SEQUENCE IF EXISTS public.measures_id_seq;
DROP TABLE IF EXISTS public.measures;
DROP SEQUENCE IF EXISTS public.equipment_values_id_seq;
DROP TABLE IF EXISTS public.equipment_values;
DROP SEQUENCE IF EXISTS public.devices_id_seq;
DROP TABLE IF EXISTS public.devices;
DROP SEQUENCE IF EXISTS public.device_paths_id_seq;
DROP TABLE IF EXISTS public.device_paths;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: device_paths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_paths (
    id integer NOT NULL,
    longitude numeric(24,8) NOT NULL,
    latitude numeric(24,8) NOT NULL,
    time_stamp timestamp without time zone NOT NULL,
    device_id integer NOT NULL,
    accepted_at timestamp without time zone NOT NULL,
    uid character varying(128) NOT NULL
);


ALTER TABLE public.device_paths OWNER TO postgres;

--
-- Name: device_paths_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.device_paths_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_paths_id_seq OWNER TO postgres;

--
-- Name: device_paths_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.device_paths_id_seq OWNED BY public.device_paths.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    model character varying(256) NOT NULL,
    serial_number character varying(128) NOT NULL,
    photo_path character varying(2048) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    created_by integer NOT NULL,
    is_deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer,
    token uuid NOT NULL,
    client_app_version character varying(16),
    activated boolean,
    activated_at timestamp without time zone
);


ALTER TABLE public.devices OWNER TO postgres;

--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devices_id_seq OWNER TO postgres;

--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: equipment_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipment_values (
    id integer NOT NULL,
    equipment_id integer NOT NULL,
    value double precision NOT NULL,
    captured_at timestamp without time zone NOT NULL,
    longitude double precision NOT NULL,
    latitude double precision NOT NULL,
    accepted_at timestamp without time zone NOT NULL,
    sender_token character varying(256) NOT NULL
);


ALTER TABLE public.equipment_values OWNER TO postgres;

--
-- Name: equipment_values_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.equipment_values_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.equipment_values_id_seq OWNER TO postgres;

--
-- Name: equipment_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.equipment_values_id_seq OWNED BY public.equipment_values.id;


--
-- Name: measures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.measures (
    id bigint NOT NULL,
    trub_dav numeric(18,6),
    trub_temp numeric(18,6),
    zatrub_dav numeric(18,6),
    zatrub_temp numeric(18,6),
    temp_pos_shtut numeric(18,6),
    dav_na_mkp numeric(18,6),
    longitude numeric(24,8) NOT NULL,
    latitude numeric(24,8) NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    dav_pos_shtut numeric(18,6),
    accepted_at timestamp without time zone NOT NULL,
    device_id integer NOT NULL,
    oil_well_id integer NOT NULL
);


ALTER TABLE public.measures OWNER TO postgres;

--
-- Name: measures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.measures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.measures_id_seq OWNER TO postgres;

--
-- Name: measures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.measures_id_seq OWNED BY public.measures.id;


--
-- Name: oil_well_equipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oil_well_equipments (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    code character varying(64) NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    created_by integer NOT NULL,
    oil_well_id integer NOT NULL,
    short_name character varying(16) NOT NULL,
    equipment_type integer NOT NULL
);


ALTER TABLE public.oil_well_equipments OWNER TO postgres;

--
-- Name: oil_equipment_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oil_equipment_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oil_equipment_types_id_seq OWNER TO postgres;

--
-- Name: oil_equipment_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oil_equipment_types_id_seq OWNED BY public.oil_well_equipments.id;


--
-- Name: oil_fields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oil_fields (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    short_name character varying(16) NOT NULL,
    code character varying(64) NOT NULL,
    is_deleted boolean NOT NULL,
    deleted_by integer,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    created_by integer NOT NULL
);


ALTER TABLE public.oil_fields OWNER TO postgres;

--
-- Name: oil_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oil_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oil_fields_id_seq OWNER TO postgres;

--
-- Name: oil_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oil_fields_id_seq OWNED BY public.oil_fields.id;


--
-- Name: oil_wells; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oil_wells (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    short_name character varying(16) NOT NULL,
    code character varying(64) NOT NULL,
    latitude numeric(24,8) NOT NULL,
    longitude numeric(24,8) NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    created_by integer NOT NULL,
    oil_field_id integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public.oil_wells OWNER TO postgres;

--
-- Name: oil_wells_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oil_wells_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oil_wells_id_seq OWNER TO postgres;

--
-- Name: oil_wells_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oil_wells_id_seq OWNED BY public.oil_wells.id;


--
-- Name: tablet_user_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tablet_user_session (
    id integer NOT NULL,
    device_id integer NOT NULL,
    tablet_user_id integer NOT NULL,
    login_time timestamp without time zone NOT NULL
);


ALTER TABLE public.tablet_user_session OWNER TO postgres;

--
-- Name: tablet_user_session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tablet_user_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tablet_user_session_id_seq OWNER TO postgres;

--
-- Name: tablet_user_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tablet_user_session_id_seq OWNED BY public.tablet_user_session.id;


--
-- Name: tablet_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tablet_users (
    id integer NOT NULL,
    login character varying(64) NOT NULL,
    first_name character varying(64) NOT NULL,
    last_name character varying(64) NOT NULL,
    middle_name character varying(64) NOT NULL,
    password character varying(256) NOT NULL,
    salt character varying(128) NOT NULL
);


ALTER TABLE public.tablet_users OWNER TO postgres;

--
-- Name: tablet_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tablet_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tablet_users_id_seq OWNER TO postgres;

--
-- Name: tablet_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tablet_users_id_seq OWNED BY public.tablet_users.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token uuid NOT NULL,
    created_at timestamp without time zone NOT NULL,
    ip_address character varying(17) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_blocked boolean NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_sessions_id_seq OWNER TO postgres;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    login character varying(64) NOT NULL,
    first_name character varying(64) NOT NULL,
    last_name character varying(64) NOT NULL,
    middle_name character varying(64),
    created_at timestamp without time zone NOT NULL,
    created_by integer,
    is_blocked boolean NOT NULL,
    email character varying(64) NOT NULL,
    role_id integer NOT NULL,
    salt character varying(128),
    password character varying(128)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: device_paths id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_paths ALTER COLUMN id SET DEFAULT nextval('public.device_paths_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: equipment_values id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_values ALTER COLUMN id SET DEFAULT nextval('public.equipment_values_id_seq'::regclass);


--
-- Name: measures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures ALTER COLUMN id SET DEFAULT nextval('public.measures_id_seq'::regclass);


--
-- Name: oil_fields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oil_fields ALTER COLUMN id SET DEFAULT nextval('public.oil_fields_id_seq'::regclass);


--
-- Name: oil_well_equipments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oil_well_equipments ALTER COLUMN id SET DEFAULT nextval('public.oil_equipment_types_id_seq'::regclass);


--
-- Name: oil_wells id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oil_wells ALTER COLUMN id SET DEFAULT nextval('public.oil_wells_id_seq'::regclass);


--
-- Name: tablet_user_session id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablet_user_session ALTER COLUMN id SET DEFAULT nextval('public.tablet_user_session_id_seq'::regclass);


--
-- Name: tablet_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablet_users ALTER COLUMN id SET DEFAULT nextval('public.tablet_users_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: device_paths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device_paths (id, longitude, latitude, time_stamp, device_id, accepted_at, uid) FROM stdin;
1	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa6
2	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa1
3	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa2
4	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa3
5	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa4
6	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa5
7	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa7
8	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa8
9	23.44400000	39.90800000	2022-07-21 17:00:55.549	1	2022-07-21 17:00:55.549	3fa85f64-5717-4562-b3fc-2c963f66afa9
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.devices (id, name, model, serial_number, photo_path, created_at, created_by, is_deleted, deleted_at, deleted_by, token, client_app_version, activated, activated_at) FROM stdin;
1	name	model	serialNumber	photoPath	2022-07-21 21:59:10.594067	0	f	\N	\N	3fa85f64-5717-4562-b3fc-2c963f66afa6	\N	\N	\N
\.


--
-- Data for Name: equipment_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipment_values (id, equipment_id, value, captured_at, longitude, latitude, accepted_at, sender_token) FROM stdin;
\.


--
-- Data for Name: measures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.measures (id, trub_dav, trub_temp, zatrub_dav, zatrub_temp, temp_pos_shtut, dav_na_mkp, longitude, latitude, created_by, created_at, dav_pos_shtut, accepted_at, device_id, oil_well_id) FROM stdin;
\.


--
-- Data for Name: oil_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oil_fields (id, name, short_name, code, is_deleted, deleted_by, deleted_at, created_at, created_by) FROM stdin;
3	Южный Харикелди	ЮХ	S-KH	f	\N	\N	0001-01-01 00:00:00	0
\.


--
-- Data for Name: oil_well_equipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oil_well_equipments (id, name, code, is_deleted, created_at, created_by, oil_well_id, short_name, equipment_type) FROM stdin;
\.


--
-- Data for Name: oil_wells; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oil_wells (id, name, short_name, code, latitude, longitude, is_deleted, created_at, created_by, oil_field_id, deleted_at, deleted_by) FROM stdin;
1	string	string	string	18.00260000	34.34400000	f	2022-07-21 21:43:03.160261	0	3	\N	\N
\.


--
-- Data for Name: tablet_user_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tablet_user_session (id, device_id, tablet_user_id, login_time) FROM stdin;
\.


--
-- Data for Name: tablet_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tablet_users (id, login, first_name, last_name, middle_name, password, salt) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (id, user_id, token, created_at, ip_address, expires_at, is_blocked) FROM stdin;
2	1	af6f9ccf-7ef4-4058-84de-4222cd7b6652	2022-07-19 21:23:45.297284	::1	2022-08-03 21:23:45.29729	f
4	1	64353f5b-8782-4f6b-a7bb-1ed756f3ea7c	2022-07-21 21:02:04.400521	::1	2022-08-05 21:02:04.400898	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, login, first_name, last_name, middle_name, created_at, created_by, is_blocked, email, role_id, salt, password) FROM stdin;
1	string	string	string	string	2022-07-19 20:36:49.612273	\N	f	string	1	wiK4BVo8gDjN985jYzwPyQ==	JGZeg92ALNcRK9Rhr3VwgB1ADLjyqdNjZNot0tLjnIk=
\.


--
-- Name: device_paths_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.device_paths_id_seq', 9, true);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, true);


--
-- Name: equipment_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.equipment_values_id_seq', 1, false);


--
-- Name: measures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.measures_id_seq', 1, false);


--
-- Name: oil_equipment_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oil_equipment_types_id_seq', 1, false);


--
-- Name: oil_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oil_fields_id_seq', 3, true);


--
-- Name: oil_wells_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oil_wells_id_seq', 1, true);


--
-- Name: tablet_user_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tablet_user_session_id_seq', 1, false);


--
-- Name: tablet_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tablet_users_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: device_paths device_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_paths
    ADD CONSTRAINT device_paths_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: equipment_values equipment_values_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipment_values
    ADD CONSTRAINT equipment_values_pkey PRIMARY KEY (id);


--
-- Name: measures measures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures
    ADD CONSTRAINT measures_pkey PRIMARY KEY (id);


--
-- Name: oil_well_equipments oil_equipment_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oil_well_equipments
    ADD CONSTRAINT oil_equipment_types_pkey PRIMARY KEY (id);


--
-- Name: oil_fields oil_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oil_fields
    ADD CONSTRAINT oil_fields_pkey PRIMARY KEY (id);


--
-- Name: oil_wells oil_wells_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oil_wells
    ADD CONSTRAINT oil_wells_pkey PRIMARY KEY (id);


--
-- Name: tablet_user_session tablet_user_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablet_user_session
    ADD CONSTRAINT tablet_user_session_pkey PRIMARY KEY (id);


--
-- Name: tablet_users tablet_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tablet_users
    ADD CONSTRAINT tablet_users_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

